# 📱 Call Timer 45s - Installation & Usage Guide

## Quick Start for Nothing Phone 3a (Android 15)

### ⚡ What This App Does
- Monitors your phone calls in real-time
- Starts timer ONLY when call is connected (not during ringing)
- Alerts you with notification + vibration at exactly **45 seconds**
- Helps you limit talk time to 45 seconds per call

---

## 📥 INSTALLATION STEPS

### Option A: Install APK Directly on Phone
1. **Download** the APK file (`CallTimer45.apk`) to your Nothing Phone 3a
2. **Open** the APK file using your file manager
3. **Tap Install** - You may see "Install blocked" warning
4. **Allow from this source** - Enable installation from unknown sources
5. **Install** - Tap Install again
6. **Done!** - App is now installed

### Option B: Install via Computer (ADB)
```bash
# 1. Connect Nothing Phone 3a to computer via USB
# 2. Enable USB Debugging on phone:
#    Settings → About Phone → Tap "Build Number" 7 times
#    Settings → System → Developer Options → Enable USB Debugging
# 3. Run this command on computer:
adb install CallTimer45.apk
```

---

## 🚀 FIRST TIME SETUP

### Step 1: Launch App
- Open "Call Timer 45s" from app drawer
- You'll see the main screen with Start/Stop buttons

### Step 2: Grant Permissions
- Tap **"Start Monitoring"** button
- You'll be asked to grant these permissions:
  
  ✅ **Phone** - To detect when calls start/end  
  ✅ **Notifications** - To alert you at 45 seconds  
  ✅ **Call Log** - To track call connection status  

- **Tap "Allow" for all permissions**

### Step 3: Start Monitoring
- Once permissions are granted, monitoring starts automatically
- You'll see "Status: Monitoring Active"
- A persistent notification shows the app is running

---

## 📞 HOW TO USE

### During a Call:
1. **Make or receive a call**
2. **While ringing** - Timer does NOT start yet
3. **When call connects** - Timer starts counting from 0
4. **At 45 seconds** - You get:
   - 🔔 Notification: "45 Seconds Reached!"
   - 📳 Vibration pattern
   - 🔊 Alert sound

### What Happens:
- **Before 45s**: No interruption, call continues normally
- **At 45s**: Alert notification appears (call is NOT disconnected)
- **After 45s**: You decide whether to continue or end the call

### Controls:
- **Stop Monitoring**: Tap red button to disable (no more alerts)
- **Start Monitoring**: Tap green button to enable again
- **Background Operation**: App works even when closed

---

## ⚙️ IMPORTANT SETTINGS

### 1. Battery Optimization (CRITICAL!)
To ensure the app works reliably:

**Settings → Battery → Battery Optimization**
- Find "Call Timer 45s"
- Set to **"Don't optimize"** or **"Unrestricted"**

Why? Android may kill background apps to save battery. This prevents that.

### 2. Notification Settings
**Settings → Apps → Call Timer 45s → Notifications**
- Enable all notification categories
- Set priority to "High" or "Urgent"
- Allow notification sound

### 3. Nothing OS Specific
**Settings → Battery → App Battery Usage**
- Add "Call Timer 45s" to **Never Sleep list**

---

## 🔧 TROUBLESHOOTING

### ❌ App doesn't detect my calls
**Solution:**
1. Check permissions: Settings → Apps → Call Timer 45s → Permissions
2. Ensure "Phone" and "Call Log" are allowed
3. Restart the app
4. Make sure "Start Monitoring" button was tapped

### ❌ No notification at 45 seconds
**Solution:**
1. Check notification permission is granted
2. Verify phone is not in Do Not Disturb mode
3. Check alarm/notification volume is not muted
4. Disable battery optimization for the app

### ❌ Monitoring stops randomly
**Solution:**
1. Disable battery optimization (see Settings section above)
2. Add app to "Never Sleep" list
3. Ensure Background App Refresh is enabled
4. Restart phone and try again

### ❌ Timer seems inaccurate
**Solution:**
- Timer is accurate to ±100ms
- Ensure phone is not under heavy load
- Check that monitoring started when app was launched
- Restart the app if issue persists

---

## 📊 TECHNICAL SPECIFICATIONS

| Feature | Details |
|---------|---------|
| **Timer Duration** | Exactly 45 seconds |
| **Accuracy** | ±100 milliseconds |
| **Ringing Excluded** | ✅ Yes |
| **Background Mode** | ✅ Foreground Service |
| **Android Version** | 15 (API 35) |
| **Minimum Android** | 7.0 (API 24) |
| **Phone Compatibility** | Nothing Phone 3a optimized |
| **Internet Required** | ❌ No (fully offline) |
| **Data Collection** | ❌ None (100% private) |

---

## 🔒 PRIVACY & PERMISSIONS

### What Permissions Are Used:
- **Phone State**: Detect call start/end/connection
- **Call Log**: Monitor when call actually connects (vs ringing)
- **Notifications**: Show 45-second alert
- **Vibrate**: Vibration feedback
- **Foreground Service**: Keep monitoring active

### What We DON'T Do:
- ❌ NO call recording
- ❌ NO internet connection
- ❌ NO data collection
- ❌ NO tracking
- ❌ NO ads

**Everything happens locally on your device.**

---

## 💡 TIPS & BEST PRACTICES

1. **Keep app open once** after installation to ensure permissions are granted
2. **Disable battery optimization** - Most important for reliability
3. **Test with a friend** - Make a test call to verify it works
4. **Check notification sound** - Ensure you can hear the alert
5. **Restart if needed** - If issues occur, restart the app

---

## 📱 COMPATIBILITY

### Tested On:
- ✅ Nothing Phone 3a (Android 15)
- ✅ Android 15 (API 35)

### Should Work On:
- Most Android phones running Android 7.0+
- Other Nothing Phone models
- Stock Android devices

### May Have Issues:
- Heavily customized Android versions
- Phones with aggressive battery optimization
- Some Chinese manufacturer ROMs (MIUI, ColorOS, etc.)

---

## 🆘 NEED HELP?

### Check These First:
1. All permissions granted?
2. Battery optimization disabled?
3. Notifications enabled?
4. Monitoring is started (green button disabled)?

### Still Not Working?
1. Restart the app completely (force stop, then reopen)
2. Restart your phone
3. Uninstall and reinstall the app
4. Check if other call-related apps are interfering

---

## 📋 VERSION INFORMATION

**Version**: 1.0  
**Build Date**: 2026  
**Target Device**: Nothing Phone 3a  
**Android Version**: 15  

**Features in v1.0:**
- 45-second call timer
- Ringing time exclusion
- Notification alerts
- Vibration feedback
- Background monitoring
- Simple UI controls

---

## ⚡ Quick Reference Card

```
┌─────────────────────────────────────┐
│  CALL TIMER 45s - QUICK GUIDE      │
├─────────────────────────────────────┤
│                                     │
│  1. TAP: "Start Monitoring"         │
│  2. GRANT: All permissions          │
│  3. MAKE CALL: Timer auto-starts    │
│  4. AT 45s: You get notified        │
│                                     │
│  ⚠️  IMPORTANT:                     │
│  • Disable battery optimization     │
│  • Keep notifications enabled       │
│  • Add to Never Sleep list          │
│                                     │
└─────────────────────────────────────┘
```

---

**Enjoy your precise 45-second call timer! 📞⏱️**
