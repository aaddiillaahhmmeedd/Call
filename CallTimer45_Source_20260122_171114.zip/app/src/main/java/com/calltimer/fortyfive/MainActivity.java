package com.calltimer.fortyfive;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private TextView statusText;
    private Button startButton;
    private Button stopButton;
    private boolean isServiceRunning = false;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean allGranted = true;
                for (Boolean granted : result.values()) {
                    if (!granted) {
                        allGranted = false;
                        break;
                    }
                }
                if (allGranted) {
                    startMonitoringService();
                } else {
                    Toast.makeText(this, "Permissions required for call monitoring", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);

        startButton.setOnClickListener(v -> checkPermissionsAndStart());
        stopButton.setOnClickListener(v -> stopMonitoringService());

        updateUI();
    }

    private void checkPermissionsAndStart() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = new String[]{
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.POST_NOTIFICATIONS
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CALL_LOG
            };
        }

        boolean allPermissionsGranted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        if (allPermissionsGranted) {
            startMonitoringService();
        } else {
            permissionLauncher.launch(permissions);
        }
    }

    private void startMonitoringService() {
        Intent serviceIntent = new Intent(this, CallMonitorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        isServiceRunning = true;
        updateUI();
        Toast.makeText(this, "Call monitoring started", Toast.LENGTH_SHORT).show();
    }

    private void stopMonitoringService() {
        Intent serviceIntent = new Intent(this, CallMonitorService.class);
        stopService(serviceIntent);
        isServiceRunning = false;
        updateUI();
        Toast.makeText(this, "Call monitoring stopped", Toast.LENGTH_SHORT).show();
    }

    private void updateUI() {
        if (isServiceRunning) {
            statusText.setText("Status: Monitoring Active\n\nThe app will notify you after 45 seconds of talk time.");
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
        } else {
            statusText.setText("Status: Inactive\n\nTap 'Start Monitoring' to begin tracking your call duration.");
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        }
    }
}
