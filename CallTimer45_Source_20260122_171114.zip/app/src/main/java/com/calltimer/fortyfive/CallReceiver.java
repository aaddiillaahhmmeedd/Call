package com.calltimer.fortyfive;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.telephony.TelephonyManager;
import androidx.core.app.NotificationCompat;

public class CallReceiver extends BroadcastReceiver {

    private static final String ALERT_CHANNEL_ID = "CallTimerAlert";
    private static final int ALERT_NOTIFICATION_ID = 2;
    private static final long TIMER_DURATION_MS = 45000; // 45 seconds

    private static Handler timerHandler;
    private static Runnable timerRunnable;
    private static boolean isTimerRunning = false;
    private static boolean hasNotified = false;

    @Override
    public void onReceive(Context context, Intent intent) {
        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        if (state == null) {
            return;
        }

        switch (state) {
            case TelephonyManager.EXTRA_STATE_RINGING:
                // Call is ringing, don't start timer yet
                stopTimer();
                hasNotified = false;
                break;

            case TelephonyManager.EXTRA_STATE_OFFHOOK:
                // Call connected, start the 45-second timer
                if (!isTimerRunning) {
                    startTimer(context);
                }
                break;

            case TelephonyManager.EXTRA_STATE_IDLE:
                // Call ended, stop timer
                stopTimer();
                hasNotified = false;
                break;
        }
    }

    private void startTimer(Context context) {
        if (isTimerRunning) {
            return;
        }

        isTimerRunning = true;
        hasNotified = false;

        if (timerHandler == null) {
            timerHandler = new Handler(Looper.getMainLooper());
        }

        timerRunnable = () -> {
            if (!hasNotified) {
                showTimerAlert(context);
                triggerVibration(context);
                hasNotified = true;
            }
            isTimerRunning = false;
        };

        timerHandler.postDelayed(timerRunnable, TIMER_DURATION_MS);
    }

    private void stopTimer() {
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
        isTimerRunning = false;
    }

    private void showTimerAlert(Context context) {
        createAlertNotificationChannel(context);

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) {
            alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("⏱️ 45 Seconds Reached!")
                .setContentText("You've been on the call for 45 seconds.")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVibrate(new long[]{0, 500, 200, 500})
                .setSound(alarmSound)
                .setAutoCancel(true)
                .setOngoing(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(ALERT_CHANNEL_ID);
        }

        NotificationManager notificationManager = 
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        
        if (notificationManager != null) {
            notificationManager.notify(ALERT_NOTIFICATION_ID, builder.build());
        }
    }

    private void createAlertNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    ALERT_CHANNEL_ID,
                    "Call Timer Alerts",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Alerts when 45 seconds of talk time is reached");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 200, 500});
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                    null
            );

            NotificationManager notificationManager = 
                    context.getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private void triggerVibration(Context context) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                VibrationEffect effect = VibrationEffect.createWaveform(
                        new long[]{0, 500, 200, 500, 200, 500}, -1);
                vibrator.vibrate(effect);
            } else {
                vibrator.vibrate(new long[]{0, 500, 200, 500, 200, 500}, -1);
            }
        }
    }
}
