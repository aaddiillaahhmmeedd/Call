#!/bin/bash

# This script creates a distributable package of the Android app
# Since we cannot build APK without Android SDK, we package the source code

echo "================================================"
echo "  Call Timer 45s - Package Creator"
echo "================================================"
echo ""

PROJECT_DIR="/home/user/CallTimerApp"
OUTPUT_DIR="/mnt/user-data/outputs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PACKAGE_NAME="CallTimer45_Source_${TIMESTAMP}"

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Create a distributable package
cd "$PROJECT_DIR"

echo "📦 Creating source package..."
zip -r "${OUTPUT_DIR}/${PACKAGE_NAME}.zip" . \
    -x "*.git*" \
    -x "*build/*" \
    -x "*.gradle/*" \
    -x "*/.idea/*" \
    > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "✅ Package created successfully!"
    echo ""
    echo "📁 Package location: ${OUTPUT_DIR}/${PACKAGE_NAME}.zip"
    echo ""
    echo "================================================"
    echo "  TO BUILD THE APK, YOU NEED:"
    echo "================================================"
    echo ""
    echo "Option 1: Build on your computer with Android Studio"
    echo "  1. Extract the ZIP file"
    echo "  2. Open the project in Android Studio"
    echo "  3. Wait for Gradle sync to complete"
    echo "  4. Build → Build Bundle(s) / APK(s) → Build APK(s)"
    echo "  5. APK will be in: app/build/outputs/apk/debug/"
    echo ""
    echo "Option 2: Build using Gradle command line"
    echo "  1. Extract the ZIP file"
    echo "  2. Open terminal in extracted folder"
    echo "  3. Run: ./gradlew assembleDebug"
    echo "  4. APK will be in: app/build/outputs/apk/debug/"
    echo ""
    echo "Option 3: Use online Android build service"
    echo "  - Upload to: https://www.apphub.com"
    echo "  - Or use: https://appetize.io"
    echo ""
    echo "================================================"
    echo "  PROJECT STRUCTURE:"
    echo "================================================"
    ls -lah "${OUTPUT_DIR}/${PACKAGE_NAME}.zip"
else
    echo "❌ Failed to create package"
    exit 1
fi

# Create a quick reference file
cat > "${OUTPUT_DIR}/BUILD_INSTRUCTIONS.txt" << 'EOF'
==============================================
  CALL TIMER 45s - BUILD INSTRUCTIONS
==============================================

PREREQUISITES:
- Android Studio Hedgehog or later
- JDK 11 or higher
- Android SDK with API 35 installed

BUILDING THE APK:

Step 1: Extract the source ZIP file
Step 2: Open Android Studio
Step 3: Click "Open" and select the extracted folder
Step 4: Wait for Gradle sync (may take 5-10 minutes first time)
Step 5: Click Build → Build Bundle(s) / APK(s) → Build APK(s)
Step 6: Once complete, click "locate" to find the APK

The APK will be located at:
  app/build/outputs/apk/debug/app-debug.apk

INSTALLING ON PHONE:
1. Copy app-debug.apk to your Nothing Phone 3a
2. Open the APK file
3. Allow installation from unknown sources
4. Install the app

ALTERNATIVE - Command Line Build:
  cd CallTimerApp
  ./gradlew assembleDebug

For release build (requires signing):
  ./gradlew assembleRelease

TROUBLESHOOTING:
- If Gradle sync fails, check your internet connection
- Ensure Android SDK API 35 is installed
- Update Android Studio to latest version
- Clear Gradle cache if needed

==============================================
For detailed instructions, see README.md
==============================================
EOF

echo ""
echo "📄 Build instructions saved to: ${OUTPUT_DIR}/BUILD_INSTRUCTIONS.txt"
echo ""
echo "✨ All files ready for distribution!"
