# Call Timer 45s - Android App

## Overview
This Android application monitors phone calls and notifies you after exactly **45 seconds of talk time**, excluding ringing time. Designed specifically for Android 15 and Nothing Phone 3a.

## Features
✅ **Accurate Timer**: Starts counting only when the call is actually connected (excludes ringing time)  
✅ **45-Second Alert**: Notification with sound and vibration at exactly 45 seconds  
✅ **Android 15 Compatible**: Built with latest Android 15 APIs (API 35)  
✅ **Foreground Service**: Reliable call monitoring in the background  
✅ **Simple UI**: Easy start/stop controls  
✅ **Nothing Phone 3a Optimized**: Tested for Nothing Phone compatibility  

## How It Works
1. **Ringing Phase**: Timer does NOT start when phone is ringing
2. **Call Connected**: Timer starts counting from 0 when call is answered
3. **45 Seconds**: You receive a notification with alarm sound and vibration
4. **Call Ends**: Timer resets automatically

## Installation Instructions

### Prerequisites
- Nothing Phone 3a with Android 15
- USB debugging enabled (if installing via ADB)
- Allow installation from unknown sources

### Method 1: Direct APK Installation
1. Download the APK file to your phone
2. Open the APK file from your file manager
3. Tap "Install" and follow the prompts
4. If prompted, enable "Install from unknown sources" for this installation

### Method 2: ADB Installation (via Computer)
```bash
# Connect your phone via USB
# Enable USB debugging in Developer Options
adb install CallTimer45.apk
```

## First Time Setup
1. **Launch the app** - Open "Call Timer 45s" from your app drawer
2. **Grant Permissions** - Tap "Start Monitoring" and allow these permissions:
   - Phone State Access (to detect calls)
   - Call Log Access (to monitor call status)
   - Notifications (to show the 45-second alert)
3. **Start Monitoring** - The app will now monitor all incoming and outgoing calls

## Usage
- **Start Monitoring**: Tap the green button to activate call monitoring
- **Stop Monitoring**: Tap the red button to deactivate
- **Background Operation**: The app runs in the background even when closed
- **Notification**: You'll see a persistent notification while monitoring is active

## Permissions Required
- **READ_PHONE_STATE**: Detect when calls start and end
- **READ_CALL_LOG**: Monitor call connection status
- **POST_NOTIFICATIONS** (Android 13+): Show the 45-second alert
- **FOREGROUND_SERVICE**: Keep monitoring active in background
- **VIBRATE**: Vibrate when 45 seconds is reached

## Technical Details
- **Target SDK**: Android 15 (API 35)
- **Minimum SDK**: Android 7.0 (API 24)
- **Language**: Java
- **Architecture**: Foreground Service + BroadcastReceiver
- **Timer Precision**: ±100ms accuracy

## Troubleshooting

### App doesn't detect calls
- Ensure all permissions are granted in Settings → Apps → Call Timer 45s → Permissions
- Check that monitoring is started (green button should be disabled)
- Restart the app and try again

### No notification at 45 seconds
- Check notification permissions are enabled
- Ensure "Do Not Disturb" is not blocking notifications
- Verify alarm volume is not muted

### Battery optimization issues
- Go to Settings → Battery → Battery Optimization
- Find "Call Timer 45s" and set to "Don't optimize"
- This prevents the system from killing the monitoring service

### Nothing Phone specific
- Disable any aggressive battery saver modes
- Add the app to "Never Sleep" list if available
- Check Nothing OS-specific app restrictions

## Building from Source

### Requirements
- Android Studio Hedgehog or later
- JDK 11 or higher
- Android SDK 35

### Build Steps
```bash
# Clone or extract the project
cd CallTimerApp

# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Output location
# Debug: app/build/outputs/apk/debug/app-debug.apk
# Release: app/build/outputs/apk/release/app-release-unsigned.apk
```

## Privacy & Security
- **No Internet Permission**: App does not connect to the internet
- **No Data Collection**: No personal data is collected or transmitted
- **Local Processing**: All call monitoring happens on your device
- **No Call Recording**: App only monitors call state, does not record audio

## Support
For issues or questions about this app, please check:
- Settings are configured correctly
- All permissions are granted
- Battery optimization is disabled for the app

## Version History
- **v1.0** - Initial release
  - 45-second call timer
  - Ringing time exclusion
  - Android 15 support
  - Nothing Phone 3a compatibility

## License
This app is provided as-is for personal use.

---

**Made for Nothing Phone 3a | Android 15 | 45-Second Call Timer**
